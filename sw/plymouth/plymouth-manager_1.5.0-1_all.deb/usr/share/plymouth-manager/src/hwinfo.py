##
#   Project: plymouth-manager - Manage your Ubuntu's Plymouth with ease  
#   Author: Mario Guerriero <mefrio.g@gmail.com>
#   Copyright: 2011 Mario Guerriero
#   License: GPL-3+
#  This program is free software; you can redistribute it and/or modify it
#  under the terms of the GNU General Public License as published by the Free
#  Software Foundation; either version 3 of the License, or (at your option)
#  any later version.
#
#  This program is distributed in the hope that it will be useful, but WITHOUT
#  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
#  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
#  more details.
#
# On Debian GNU/Linux systems, the full text of the GNU General Public License
# can be found in the file /usr/share/common-licenses/GPL-3.
##

import os, subprocess, ConfigParser, getpass

#get the resolutions

def getRes():

   # Xrandr Part

   cmd = 'xrandr' 
   tmpBuf = subprocess.Popen(cmd, shell=True, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True) # Redirect Output
   buf = tmpBuf.stdout.read()

   avlRes = [] # Available Resolutions

   for line in buf.split('\n'):
       if 'Screen' in line:
          for item in line.split(': ')[1].split(', '):
              if 'minimum' in item:
                 minRes = item.replace('minimum', '').replace(' ', '')
              elif 'current' in item:
                 curRes = item.replace('current', '').replace(' ', '')
              elif 'maximum' in item:
                 maxRes = item.replace('maximum', '').replace(' ', '')
       else:
          for item in line.split():
              if item and 'x' in item and len(item) > 2 and not '+' in item and not 'axis' in item:
                 avlRes.append(item)
                 
   return avlRes  
	
#get the bootloader
def getBoot():
	if os.path.exists("/home/" + getpass.getuser() + "/.plymouth-manager.cf"):
		Config = ConfigParser.RawConfigParser()  
		Config.read("/home/" + getpass.getuser() + "/.plymouth-manager.cf")
		boot = Config.get("Boot options", "BOOT_LOADER")
		return str(boot)
	else:
		if os.path.isfile('/etc/default/grub'): # Grub
			return 'grub'
		elif os.path.isfile('/etc/default/burg'): # Burg
			return 'burg'
		else:
			return 'error'
