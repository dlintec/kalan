##
#   Project: plymouth-manager - Manage your Ubuntu's Plymouth with ease  
#   Author: Mario Guerriero <mefrio.g@gmail.com>
#   Copyright: 2011 Mario Guerriero
#   License: GPL-3+
#  This program is free software; you can redistribute it and/or modify it
#  under the terms of the GNU General Public License as published by the Free
#  Software Foundation; either version 3 of the License, or (at your option)
#  any later version.
#
#  This program is distributed in the hope that it will be useful, but WITHOUT
#  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
#  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
#  more details.
#
# On Debian GNU/Linux systems, the full text of the GNU General Public License
# can be found in the file /usr/share/common-licenses/GPL-3.
##

import gtk, gtk.glade, pygtk								#pygtk modules
import os, sys, shutil, getpass, ConfigParser				#others modules
import funcmain, hwinfo, themescontroller, handlepaths		#personal modules
import gettext						#gettext
from gettext import gettext as _

#class for the main window
class PlymouthManager:
	def __init__(self):	
		#functions of wndMain
		def on_wndMain_destroy(widget, data=None):
			gtk.main_quit()

		#general tab
		def on_btnChangeRes_clicked(widget, data=None):
			funcmain.ChangeRes(self.cmbResolution.get_active_text())

            
		def on_btnAbleDisable_clicked(widget, data=None):
			funcmain.AbleDisable()
			self.getPlymouthStatus()
			
		def on_btnBurg_clicked(widget, data=None):
			funcmain.Burg()
			self.btnBurg.set_sensitive(False)

		def on_btnDriver_clicked(widget, data=None):
			funcmain.Driver()

		def on_btnEdit_clicked(widget, data=None):
			funcmain.Edit()

		#themes tab
		def on_btnRefresh_clicked(widget, data=None):
			funcmain.Refresh()
			self.setIconView()
		
		def on_btnInstallRemove_clicked(widget, data=None):
			funcmain.InstallRemove(self.lblTheme.get_label(), self.InstallRemoveTheme)
			self.getCurrentTheme()		
						
		def on_btnSelect_clicked(widget, data=None):
			funcmain.Select()				
		def on_btnPreview_clicked(widget, data=None):
			funcmain.Preview()
		
		def on_iconThemes_selection_changed(widget, data=None):
			self.lblTheme.set_label( funcmain.SelectIcon(self.iconThemes.get_selected_items()) )	#funcmain.SelectIcon(self.iconThemes.get_selected_items()) is used to get the name of the selected theme
			if themescontroller.ControllTheme(self.lblTheme.get_label()) == 1:
				self.btnInstallRemove.set_label(_("Remove"))
				self.InstallRemoveTheme = "r"
			else:
				self.btnInstallRemove.set_label(_("Install"))
				self.InstallRemoveTheme = "i"
						
		def on_iconThemes_size_allocate(object, rectangle):
			 columns = int(rectangle.width/(self.iconThemes.get_columns()*2))
			 self.iconThemes.set_columns(columns)
						
		#theme creation tab		
		def on_flcBtn_file_set(widget, data=None):
			if os.path.getsize(self.flcBtn.get_filename()) <= (1024*500) and (self.flcBtn.get_filename()[-3:-1] + self.flcBtn.get_filename()[-1]) == "png":
				self.btnCreate.set_sensitive(True)
				self.btnInstallTheme.set_sensitive(True)	
			else:
				self.btnCreate.set_sensitive(False)
				self.btnInstallTheme.set_sensitive(False)		
		
		def on_btnCreate_clicked(widget, data=None):
			funcmain.Create(self.flcBtn.get_filename())
			
		def on_btnInstallTheme_clicked(widget, data=None):
			funcmain.InstallTheme()
			self.getCurrentTheme

		#menubar
		def on_itemHelp_activate(widget, data=None):
			funcmain.Info()
						
		#signals
		signals = {
			"on_wndMain_destroy":on_wndMain_destroy,						#wndMain
			"on_btnChangeRes_clicked":on_btnChangeRes_clicked,				#tab general
			"on_btnAbleDisable_clicked":on_btnAbleDisable_clicked,
			"on_btnBurg_clicked":on_btnBurg_clicked,
			"on_btnDriver_clicked":on_btnDriver_clicked,
			"on_btnEdit_clicked":on_btnEdit_clicked,
			"on_btnRefresh_clicked":on_btnRefresh_clicked,			#themes tab
			"on_btnInstallRemove_clicked":on_btnInstallRemove_clicked,	
			"on_btnSelect_clicked":on_btnSelect_clicked,
			"on_btnPreview_clicked":on_btnPreview_clicked,
			"on_iconThemes_selection_changed":on_iconThemes_selection_changed,
			"on_iconThemes_size_allocate":on_iconThemes_size_allocate,
			"on_btnCreate_clicked":on_btnCreate_clicked,					#theme creation tab
			"on_btnInstallTheme_clicked":on_btnInstallTheme_clicked,
			"on_flcBtn_file_set":on_flcBtn_file_set,
			"on_itemHelp_activate":on_itemHelp_activate						#menubar
		}

                for module in (gettext, gtk.glade):
                    module.bindtextdomain('plymouth-manager', '%s/share/locale' % sys.prefix)
                    module.textdomain('plymouth-manager')
		
		#load the window
		self.MainGlade = gtk.glade.XML("../data/ui/plymouth-manager.glade")		#load the glade file
		self.wndMain = self.MainGlade.get_widget("wndMain")						#load of wndMain and its widget
		self.cmbResolution = self.MainGlade.get_widget("cmbResolution")
		self.btnAbleDisable = self.MainGlade.get_widget("btnAbleDisable")
		self.btnBurg = self.MainGlade.get_widget("btnBurg")
		self.iconThemes = self.MainGlade.get_widget("iconThemes")
		self.lblTheme = self.MainGlade.get_widget("lblTheme")
		self.btnInstallRemove = self.MainGlade.get_widget("btnInstallRemove")
		self.lblCurrentTheme = self.MainGlade.get_widget("lblCurrentTheme")
		self.btnPreview = self.MainGlade.get_widget("btnPreview")
		self.flcBtn = self.MainGlade.get_widget("flcBtn")
		self.btnCreate = self.MainGlade.get_widget("btnCreate")
		self.btnInstallTheme = self.MainGlade.get_widget("btnInstallTheme")
				
		#set combobox with the resolutions
		tmpInfo = hwinfo.getRes()
		
		cmbModelScore = gtk.ListStore(str)
		count = 0
		for value in tmpInfo:
			iter=cmbModelScore.append()
			cmbModelScore.set_value(iter, 0, value)
			self.cmbResolution.set_model(cmbModelScore)
		        cell = gtk.CellRendererText()
                        if value == funcmain.getCurrentRes():
                            
                            self.cmbResolution.set_active(count)
                        else:
                            count += 1
		self.cmbResolution.pack_start(cell, True)
                self.cmbResolution.add_attribute(cell, 'text',0)
		
		#singals controller		
		self.MainGlade.signal_autoconnect(signals)		
		
		#iconv view
		"""self.icons = os.listdir("../data/themes_preview")
		
		liststore = gtk.ListStore(gtk.gdk.Pixbuf)
		self.iconThemes.set_model(liststore)
		self.iconThemes.set_pixbuf_column(0)

		for icon in self.icons:
			pixbuf = gtk.gdk.pixbuf_new_from_file_at_size("../data/themes_preview/" + icon, 100, 100)
			liststore.append([pixbuf])
		"""	
		#COL_ICON, COL_NAME, COL_INDEX = (0, 1, 2)
		#self.iconThemes.set_text_column(COL_NAME)
		#self.iconThemes.set_pixbuf_column(COL_ICON)
		
		#function before the launch of PM
		self.getPlymouthStatus()			
		self.getCurrentResolution()
		self.getBootLoaderStatus()
		self.getCurrentTheme()
		self.setIconView()

		#show the window
		if self.wndMain:
			self.wndMain.show()
			gtk.main()
		else:
			print "error"
			
	def getPlymouthStatus(self):
		#check plymouth status
		if funcmain.getPlymouthStatus() == 1:
			self.btnAbleDisable.set_label(_("Disable"))
		else:
			self.btnAbleDisable.set_label(_("Enable"))		
			
	def getCurrentResolution(self):
		#set the current resolution in the combo box
		self.cmbResolution.set_title(funcmain.getCurrentRes())
		
	def getBootLoaderStatus(self):
		if hwinfo.getBoot() == "burg":
			self.btnBurg.set_sensitive(False)
		
	def getCurrentTheme(self):
		#get the plymouth's theme in use
		if not os.path.isdir("/lib/plymouth/themes/default.plymouth"):
			#get theme's name
			self.fileTheme = ConfigParser.RawConfigParser()					 
			self.fileTheme.read("/lib/plymouth/themes/default.plymouth")
			self.Theme = self.fileTheme.get("Plymouth Theme", "Name")
			#set it into the label
			self.lblCurrentTheme.set_label(_("Current theme: ") + self.Theme)
		else:
			self.btnPreview.set_sensitive(False)
			
	def setIconView(self):
		self.icons = os.listdir("../data/themes_preview")
		
		liststore = gtk.ListStore(gtk.gdk.Pixbuf)
		self.iconThemes.set_model(liststore)
		self.iconThemes.set_pixbuf_column(0)
		
		for icon in self.icons:
			pixbuf = gtk.gdk.pixbuf_new_from_file_at_size("../data/themes_preview/" + icon, 100, 100)
			liststore.append([pixbuf])

#class for editor window
class Editor():
	def __init__(self):
		#definictions of the functions
		#window
		def on_wndEditor_destroy(widget, data=None):
			self.wndEditor.destroy()
		
		#button
		def on_btnSave_clicked(widget, data=None):
			#get buffer, bound and text
			bufferEditor = self.txvEditor.get_buffer()
			start, end = bufferEditor.get_bounds()
			Text = bufferEditor.get_text(start, end)
			#get file name
			File = self.cmbEditor.get_active_text()
			
			funcmain.Save(Text, File)
				
		def on_btnCancel_clicked(widget, data=None):
			self.wndEditor.destroy()
			
		#combobox
		def on_cmbEditor_changed(widget, data=None):
			#get buffer, bound and text
			bufferEditor = self.txvEditor.get_buffer()
			start, end = bufferEditor.get_bounds()
			file = open(self.cmbEditor.get_active_text(), "r").read()	
			bufferEditor.set_text(file)
		
		#signals
		signals = {
			"on_wndEditor_destroy":on_wndEditor_destroy,
			"on_btnSave_clicked":on_btnSave_clicked,
			"on_btnCancel_clicked":on_btnCancel_clicked,
			"on_cmbEditor_changed":on_cmbEditor_changed
		}
			
		#load window's windgets
		self.MainGlade = gtk.glade.XML("../data/ui/plymouth-manager.glade")
		self.wndEditor = self.MainGlade.get_widget("wndEditor")
		self.cmbEditor = self.MainGlade.get_widget("cmbEditor")
		self.txvEditor = self.MainGlade.get_widget("txvEditor")

		#set combobox
		if os.path.isfile("/lib/plymouth/themes/default.plymouth"):	
			FileList = ["/lib/plymouth/themes/default.plymouth", "/lib/plymouth/themes/text.plymouth", "/etc/default/" + hwinfo.getBoot()]
		else:
			FileList = ["/lib/plymouth/themes/text.plymouth", "/etc/default/" + hwinfo.getBoot()]
		
		cmbModelScore = gtk.ListStore(str)
		
		for value in FileList:
			iter=cmbModelScore.append()
			cmbModelScore.set_value(iter, 0, value)
			self.cmbEditor.set_model(cmbModelScore)
		cell = gtk.CellRendererText()
		self.cmbEditor.pack_start(cell, True)
		self.cmbEditor.add_attribute(cell, 'text',0)
		self.cmbEditor.set_active(0) # The element is active at 0 position
		
		#set textview
		#get buffer, bound and text
		bufferEditor = self.txvEditor.get_buffer()
		start, end = bufferEditor.get_bounds()	
		file = open(self.cmbEditor.get_active_text(), "r").read()
		bufferEditor.set_text(file)	
		
		#singals controller	
		self.MainGlade.signal_autoconnect(signals)	
		
		#show the window
		if self.wndEditor:
			self.wndEditor.show_all()
		else:
			print "error"	


#class for preview windows
class Preview:
	def __init__(self):
		def on_wndPreview_destroy(widget, data=None):
			self.wndPreview.destroy()

		
		#get theme's name
		self.fileTheme = ConfigParser.RawConfigParser()					 
		self.fileTheme.read("/lib/plymouth/themes/default.plymouth")
		self.Theme = self.fileTheme.get("Plymouth Theme", "Name")		
		
		#signals
		signals = {
			"on_wndPreview_destroy":on_wndPreview_destroy
		}
			
		#load window's windgets
		self.MainGlade = gtk.glade.XML("../data/ui/plymouth-manager.glade")
		self.wndPreview = self.MainGlade.get_widget("wndPreview")
		self.imgPreview = self.MainGlade.get_widget("imgPreview")
			
		#singals controller		
		self.MainGlade.signal_autoconnect(signals)	
		
		#print "../data/themes_preview/" + self.Theme + ".jpg"
		
		if os.path.exists("../data/themes_preview/" + self.Theme + ".jpg"):
			#set the preview's immage
			self.imgPreview.set_from_file("../data/themes_preview/" + self.Theme + ".jpg")
		else:
			print "Cannot load the current theme"
			
		#show the window
		if self.wndPreview:
			self.wndPreview.show_all()
		else:
			print "error"	


#class for help window
class Info(gtk.AboutDialog):
	def __init__(self):
		gtk.AboutDialog.__init__(self)
		self.set_name(handlepaths.APP_TITLE)
		self.set_title(handlepaths.APP_TITLE)
		self.set_program_name(handlepaths.APP_TITLE)
		self.set_version(handlepaths.VERSION)
		icon=gtk.gdk.pixbuf_new_from_file("../data/icons/plymouth-manager-logo.png")
		self.set_icon(icon)
		self.set_logo(icon)
		self.set_copyright('(c) 2011')
		self.set_license(handlepaths.read_text_file('doc', 'copyright'))
		self.set_website_label('http://plymouthmanager.wordpress.com/')
		self.set_website('http://plymouthmanager.wordpress.com/')
		self.set_authors(['Mario Guerrierio <mefrio.g@gmail.com>'])
		self.set_comments('Manage your Plymouth')
		self.run()
		self.destroy()       

