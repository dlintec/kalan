##
#   Project: plymouth-manager - Manage your Ubuntu's Plymouth with ease  
#   Author: Mario Guerriero <mefrio.g@gmail.com>
#   Copyright: 2011 Mario Guerriero
#   License: GPL-3+
#  This program is free software; you can redistribute it and/or modify it
#  under the terms of the GNU General Public License as published by the Free
#  Software Foundation; either version 3 of the License, or (at your option)
#  any later version.
#
#  This program is distributed in the hope that it will be useful, but WITHOUT
#  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
#  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
#  more details.
#
# On Debian GNU/Linux systems, the full text of the GNU General Public License
# can be found in the file /usr/share/common-licenses/GPL-3.
##

import os, sys, shutil, getpass, pickle, stat, subprocess
import gtk, gtk.glade, pygtk
import hwinfo, main

#function that happen before the start of PM
#get the plymouth status (is it enabled or not?)
def getPlymouthStatus():
	if os.path.exists("/etc/init/plymouth-splash.conf"):
		return 1
	else:
		return 0

#get the resolution in use
def getCurrentRes():
	tmpBuf = open("/etc/default/" + hwinfo.getBoot(), "r")
	for line in tmpBuf:
		if "GRUB_GFXMODE=" in line:

			return line.split("=")[1].split('\n')[0]

			
#functions for the general tab
def ChangeRes(res):
	bl = hwinfo.getBoot()

	shutil.copyfile("/etc/default/" + bl, "/home/" + getpass.getuser() + "/." + bl + ".backup")

	sourceFile = open("/home/" + getpass.getuser() + "/." + bl, "w")
	
	tmpBuf = open("/home/" + getpass.getuser() + "/." + bl + ".backup", 'r').read()

	
	for line in tmpBuf.split('\n'):
		if "GRUB_GFXMODE=" in line:
			sourceFile.write("GRUB_GFXMODE=" + res + "\n")
		sourceFile.write(line + "\n")
	
	sourceFile.close()

	os.system("xterm -e 'sudo mv ." + bl + " /etc/default/" + bl + "'")
	

def AbleDisable():
	if os.path.exists("/etc/init/plymouth-splash.conf"):
		os.system("xterm -e 'sudo mv /etc/init/plymouth-splash.conf /etc/init/plymouth-splash.conf.disabled'")
	elif os.path.exists("/etc/init/plymouth-splash.conf.disabled"):
		os.system("xterm -e 'sudo mv /etc/init/plymouth-splash.conf.disabled /etc/init/plymouth-splash.conf'")
	else:
		print "ERROR: /etc/init/plymouth-splash.conf & /etc/init/plymouth-splash.conf.disabled don't exist"
		
def Burg():
	if not os.path.exists("/home/" + getpass.getuser() + "/.plymouth-manager.cf"):
		fBurg = open("/home/" + getpass.getuser() + "/.plymouth-manager.cf", "w")
		fBurg.write("[Boot options]\nBOOT_LOADER=burg")
		fBurg.close()
		
def Driver():
	'''
	if len(sys.argv) < 3:
		print 'Resolution Needed'
		sys.exit(1)

	res = sys.argv[1]
	bit = sys.argv[2]
	'''
	resOut = os.popen("xrandr  | grep \* | cut -d' ' -f4")
	res = resOut.read()
	user = os.getlogin()

	starter = hwinfo.getBoot()

	#file /etc/default/BOOTLOADER

	shutil.copy('/etc/default/' + starter, '/home/' + user + '/.' + starter + '.bak') # Backup
	tmpBuf = open('/etc/default/'+starter, 'r').read()

	sourceFile = open('/home/' + user + '/.' + starter, 'w')

	for line in tmpBuf.split('\n'):
		if 'GRUB_CMDLINE_LINUX_DEFAULT=' in line:
			sourceFile.write('GRUB_CMDLINE_LINUX_DEFAULT=\"quiet splash nomodeset video=uvesafb:mode_option='+res+'-24,mtrr=3,scroll=ywrap\"\n')
		elif 'GRUB_GFXMODE=' in line:
			sourceFile.write('GRUB_GFXMODE='+res+'\n')
		elif 'GRUB_GFXPAYLOAD_LINUX=' in line: # Wrong Fix
			if not line.startswith('#'):
				sourceFile.write('#'+line+'\n')
			else:
				sourceFile.write(line+'\n')
		else:
			sourceFile.write(line+'\n')

	sourceFile.close()

	#file /etc/initramfs-tools/modules

	shutil.copy('/etc/initramfs-tools/modules', '/home/'+user+'/.modules.bak') # Backup
	tmpBuf = open('/etc/initramfs-tools/modules', 'r').read()

	sourceFile = open('/home/'+user+'/.modules', 'w')
	isDone = 0 # Uvesafb Line Not Present

	for line in tmpBuf.split('\n'):
		if 'uvesafb' in line:
			sourceFile.write('uvesafb mode_option='+res+'-24 mtrr=3 scroll=ywrap\n')
			isDone = 1
		else:
			sourceFile.write(line+'\n')

	if isDone == 0:
		sourceFile.write('uvesafb mode_option='+res+'-24 mtrr=3 scroll=ywrap\n')

	sourceFile.close()

	#file /etc/initramfs-tools/conf.d/splash 

	sourceFile = open('/home/' + user  + '/.splash', 'w')
	sourceFile.write('FRAMEBUFFER=y\n')
	sourceFile.close()

	#saving
	if starter == 'grub':
		os.system("xterm -e 'sudo mv ." + starter + " /etc/default/" + starter + " && sudo mv .modules /etc/initramfs-tools/modules && sudo mv .splash /etc/initramfs-tools/conf.d/splash && sudo update-grub2 && sudo update-initramfs -u'")
		#os.system("xterm -e 'sudo mv .modules /etc/initramfs-tools/modules'")
		#os.system("xterm -e 'sudo mv .splash /etc/initramfs-tools/conf.d/splash'")
		#os.system("xterm -e 'sudo update-grub2 && sudo update-initramfs -u'")
		print "Operation complete!"
     
	elif starter == 'burg':
		os.system("xterm -e 'sudo mv ." + starter + " /etc/default/" + starter + " && sudo mv .modules /etc/initramfs-tools/modules && sudo mv .splash /etc/initramfs-tools/conf.d/splash && sudo update-burg && sudo update-initramfs -u'")
		#checkB = os.system("xterm -e 'sudo mv ." + starter + " /etc/default/" + starter + "'")
		#checkM = os.system("xterm -e 'sudo mv .modules /etc/initramfs-tools/modules'")
		#checkS = os.system("xterm -e 'sudo mv .splash /etc/initramfs-tools/conf.d/splash'")
		#checkU = os.system("xterm -e 'sudo update-burg && sudo update-initramfs -u'")
		print "Operation complete!"
	
def Edit():
	main.Editor()
	
#functions for the themes tab
def SelectIcon(value):
	#a and b are casual variables name
	try:
		icons = os.listdir("../data/themes_preview")
		a = str(value[0])
		b = ((a.replace("(", "")).replace(")", "")).replace(",", "")
		return icons[int(b)].replace(".jpg", "")
	except:
		return ""
	
def Refresh():
	os.system("xterm -e 'cd /usr/local/share/plymouth-manager/data/config_file && sudo rm themes.txt && sudo wget http://launchpadlibrarian.net/68472604/themes.txt'")
	
def InstallRemove(theme_name, install_remove):
	index = 0
	indexSplit = 0
	themesFile = open("../data/config_file/themes.txt", "r")
	themesLines = themesFile.readlines()
	themesFile.close()
	while theme_name not in themesLines[index]:
		index += 1
	if theme_name in themesLines[index]:
		themeSplit = str(themesLines).split("|")
	while theme_name != themeSplit[indexSplit]:
		indexSplit += 1
	if theme_name == themeSplit[indexSplit]:
		if install_remove == "i":	
			os.system("xterm -e " + themeSplit[indexSplit-1])		#system comand to install a theme	
		else:
			os.system("xterm -e " + themeSplit[indexSplit+1])		#system comand to remove a theme
	

def Select():
	os.system("xterm -e 'sudo update-alternatives --config default.plymouth && sudo update-initramfs -u'")
	
def Preview():
	main.Preview()

#functions for the themes creations tab
def Create(file_path):
	#creation of the necessary folders
	os.system("xterm -e 'sudo mkdir /lib/plymouth/themes/PMtheme'")
	os.system("xterm -e 'sudo cp " + file_path + " /lib/plymouth/themes/PMtheme'")
	
	listFile = os.listdir("/lib/plymouth/themes/PMtheme")
	for image in listFile:
		os.system("xterm -e 'sudo mv /lib/plymouth/themes/PMtheme/" + image + " /lib/plymouth/themes/PMtheme/background.png'")
		
	#creation of the necessary file
	#file.plymouth
	filePlymouth = open("/home/" + getpass.getuser() + "/.PMtheme.plymouth", "w")
	textPlymouth = "[Plymouth Theme]\nName=Theme by PM\nDescription=Theme made by Plymouth Manager\nModuleName=script\n[script]\nImageDir=/lib/plymouth/themes/PMtheme\nScriptFile=/lib/plymouth/themes/PMtheme/PMtheme.script"
	filePlymouth.write(textPlymouth)
	filePlymouth.close()
	os.system("xterm -e 'sudo mv ~/.PMtheme.plymouth /lib/plymouth/themes/PMtheme/PMtheme.plymouth'")
	#file.script
	fileScript = open("/home/" + getpass.getuser() + "/.PMtheme.script", "w")
	textScript = "wallpaper_image = Image('background.png');\nscreen_width = Window.GetWidth();\nscreen_height = Window.GetHeight();\nresized_wallpaper_image = wallpaper_image.Scale(screen_width,screen_height);\nwallpaper_sprite = Sprite(resized_wallpaper_image);\nwallpaper_sprite.SetZ(-100);"
	fileScript.write(textPlymouth)
	fileScript.close()
	os.system("xterm -e 'sudo mv ~/.PMtheme.script /lib/plymouth/themes/PMtheme/PMtheme.script'")

	
def InstallTheme():
	os.system("xterm -e ''sudo update-alternatives --install /lib/plymouth/themes/default.plymouth default.plymouth /lib/plymouth/themes/PMtheme/PMtheme.plymouth 100 && sudo update-alternatives --config default.plymouth && sudo update-initramfs -u'")

#functions for the wndEditor
def Save(Text, File):
	#fileConfig = open(File, "r").read()
	if File == "/lib/plymouth/themes/default.plymouth":
		SavingFile = "default.plymouth"
	elif File == "/lib/plymouth/themes/text.plymouth":
		SavingFile = "text.plymouth"
	else:
		SavingFile = hwinfo.getBoot()
	fileSaving = open("/home/" +getpass.getuser() + "/." + SavingFile, "w")
	fileSaving.write(Text)
	fileSaving.close()
	if File == "/lib/plymouth/themes/default.plymouth":
		os.system("xterm -e 'sudo mv ~/.default.plymouth /lib/plymouth/themes/default.plymouth'")
	elif File == "/lib/plymouth/themes/text.plymouth":
		os.system("xterm -e 'sudo mv ~/.text.plymouth /lib/plymouth/themes/text.plymouth'")
	else:
		os.system("xterm -e 'sudo mv ~/." + hwinfo.getBoot() + " /etc/default/" + hwinfo.getBoot() + "'")

#functions for the menubar
def Info():
	main.Info()
