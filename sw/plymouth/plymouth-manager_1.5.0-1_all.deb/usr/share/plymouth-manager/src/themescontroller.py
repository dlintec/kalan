##
#   Project: plymouth-manager - Manage your Ubuntu's Plymouth with ease  
#   Author: Mario Guerriero <mefrio.g@gmail.com>
#   Copyright: 2011 Mario Guerriero
#   License: GPL-3+
#  This program is free software; you can redistribute it and/or modify it
#  under the terms of the GNU General Public License as published by the Free
#  Software Foundation; either version 3 of the License, or (at your option)
#  any later version.
#
#  This program is distributed in the hope that it will be useful, but WITHOUT
#  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
#  FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
#  more details.
#
# On Debian GNU/Linux systems, the full text of the GNU General Public License
# can be found in the file /usr/share/common-licenses/GPL-3.
##


#	This file contain a function
#	which is used to controll the status of the theme...
#	Is it install or not?


import os

def ControllTheme(theme_name):
	if theme_name == "Azenis" and os.path.exists("/lib/plymouth/themes/azenis"):
		return 1
	elif theme_name == "DM Ubuntu" and os.path.exists("/lib/plymouth/themes/DM_Ubuntu"):
		return 1
	elif theme_name == "Earth Sunrise" and os.path.exists("/lib/plymouth/themes/earth-sunrise"):
		return 1
	elif theme_name == "Elementary" and os.path.exists("/lib/plymouth/themes/Elementary"):
		return 1
	elif theme_name == "Glow" and os.path.exists("/lib/plymouth/themes/glow"):
		return 1
	elif theme_name == "Internauta" and os.path.exists("/lib/plymouth/themes/Internauta"):
		return 1
	elif theme_name == "Internauta 2000" and os.path.exists("/lib/plymouth/themes/internauta2000"):
		return 1
	elif theme_name == "Kmint" and os.path.exists("/lib/plymouth/themes/Kmint"):
		return 1
	elif theme_name == "Kubuntu Logo" and os.path.exists("/lib/plymouth/themes/kubuntu-logo"):
		return 1
	elif theme_name == "Lubuntu Logo" and os.path.exists("/lib/plymouth/themes/lubuntu-logo"):
		return 1
	elif theme_name == "MIB" and os.path.exists("/lib/plymouth/themes/MIB-Ubuntu"):
		return 1
	elif theme_name == "MIB Oxygen" and os.path.exists("/lib/plymouth/themes/MIBOxygen"):
		return 1
	elif theme_name == "Orange" and os.path.exists("/lib/plymouth/themes/orange"):
		return 1
	elif theme_name == "Paw OSX" and os.path.exists("/lib/plymouth/themes/Paw-OSX"):
		return 1
	elif theme_name == "Plymouth 10.10" and os.path.exists("/lib/plymouth/themes/ubuntu_plymouth_1010"):
		return 1	
	elif theme_name == "Sabily" and os.path.exists("/lib/plymouth/themes/sabily"):
		return 1
	elif theme_name == "Seven" and os.path.exists("/lib/plymouth/themes/7"):
		return 1
	elif theme_name == "Solar" and os.path.exists("/lib/plymouth/themes/solar"):
		return 1
	elif theme_name == "Space Sunrise" and os.path.exists("/lib/plymouth/themes/space-sunrise"):
		return 1
	elif theme_name == "Stargate" and os.path.exists("/lib/plymouth/themes/Stargate"):
		return 1
	elif theme_name == "Sunrise" and os.path.exists("/lib/plymouth/themes/sunrise"):
		return 1
	elif theme_name == "Texans" and os.path.exists("/lib/plymouth/themes/Texans"):
		return 1
	elif theme_name == "Ubuntu Logo" and os.path.exists("/lib/plymouth/themes/ubuntu-logo"):
		return 1
	elif theme_name == "Ubuntu New" and os.path.exists("/lib/plymouth/themes/newsplash"):
		return 1
	elif theme_name == "Ubuntu Studio" and os.path.exists("/lib/plymouth/themes/ubuntustudio-logo"):
		return 1
	elif theme_name == "Xubuntu Logo" and os.path.exists("/lib/plymouth/themes/xubuntu-logo"):
		return 1
	elif theme_name == "AzenisBuntu" and os.path.exists("/lib/plymouth/themes/AzenisBuntu"):
		return 1
	elif theme_name == "Ubuntu Green" and os.path.exists("/lib/plymouth/themes/Ubuntu_GREEN_2_1"):
		return 1
	elif theme_name == "Ubuntu Pink" and os.path.exists("/lib/plymouth/themes/U-p"):
		return 1
	elif theme_name == "Ubuntu Pink 2" and os.path.exists("/lib/plymouth/themes/U-p_2"):
		return 1
	elif theme_name == "Fun With Linux" and os.path.exists("/lib/plymouth/themes/Fun_With_Linux_2"):
		return 1
	else:
		return 0
'''
new testing function


def ControllTheme(theme_name):
	themes = [{'name':'Azenis', 'path':'azenis'}, {'name':'DM Ubuntu', 'path':'DM_Ubuntu'}, {'name':'Earth Sunrise', 'path':'earth-sunrise'}, {'name':'Elementary', 'path':'Elementary'}, {'name':'Glow', 'path':'glow'}, {'name':'Internauta', 'path':'Internauta'}, {'name':'Internauta 2000', 'path':'internauta2000'}, {'name':'Kmint', 'path':'Kmint'}, {'name':'Kubuntu Logo', 'path':'kubuntu-logo'}, {'name':'Lubuntu Logo', 'path':'lubuntu-logo'}, {'name':'MIB', 'path':'MIB-Ubuntu'}, {'name':'MIB Oxygen', 'path':'MIBOxygen'}, {'name':'Orange', 'path':'orange'}, {'name':'Paw OSX', 'path':'Paw-OSX'}, {'name':'Paw Ubuntu', 'path':'Paw-Ubuntu'}, {'name':'Plymouth 10.10', 'path':'ubuntu_plymouth_1010'}, {'name':'Sabily', 'path':'sabily'}, {'name':'Seven', 'path':'7'}, {'name':'Solar', 'path':'solar'}, {'name':'Space Sunrise', 'path':'space-sunrise'}, {'name':'Stargate', 'path':'Stargate'}, {'name':'Sunrise', 'path':'sunrise'}, {'name':'Texans', 'path':'Texans'}, {'name':'Ubuntu Logo', 'path':'ubuntu-logo'}, {'name':'Ubuntu New', 'path':'newsplash'}, {'name':'Ubuntu Studio', 'path':'ubuntustudio'}, {'name':'Xubuntu Logo', 'path':'xubuntu-logo'}]
	for item in themes:
		if theme_name ==  item['name'] and os.path.exists('/lib/plymouth/themes/'+item['path']):
			return 1
		else:
			return 0

'''
